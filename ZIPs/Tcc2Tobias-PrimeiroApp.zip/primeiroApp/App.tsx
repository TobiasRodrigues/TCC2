import React, { useState } from "react";
import { Text, View, StyleSheet, TouchableOpacity, ActivityIndicator } from "react-native";

const DURATION_MS = 30000; // 30 segundos

export default function App() {
  const [iterations, setIterations] = useState(0);
  const [running, setRunning] = useState(false);

  const isPrime = (n: number): boolean => {
    if (n < 2) return false;
    for (let i = 2; i * i <= n; i++) {
      if (n % i === 0) return false;
    }
    return true;
  };

  const runCpu = async () => {
    if (running) return;
    setRunning(true);
    setIterations(0);

    console.log("Iniciado ts=", new Date().toISOString());
    const start = Date.now();

    while (Date.now() - start < DURATION_MS) {
      // JSON grande
      const list = Array.from({ length: 20000 }, (_, i) => ({ i, s: "x".repeat(10) }));
      const s = JSON.stringify(list);
      JSON.parse(s);

      // Ordenação
      const nums = Array.from({ length: 30000 }, () => Math.floor(Math.random() * 1000000));
      nums.sort((a, b) => a - b);

      // Primos
      let c = 0;
      for (let n = 100000; n < 101000; n++) if (isPrime(n)) c++;

      setIterations((prev) => prev + 1);
      await new Promise((r) => setTimeout(r, 0));
    }

    console.log("Finalizado ts=", new Date().toISOString());
    setRunning(false);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}>Iterações concluídas: {iterations}</Text>

      <TouchableOpacity
        style={[styles.button, running && { backgroundColor: "#444" }]}
        onPress={runCpu}
        disabled={running}
      >
        {running ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={styles.buttonText}>Iniciar Teste</Text>
        )}
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#000",
    padding: 20,
  },
  title: {
    color: "#fff",
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 10,
  },
  text: {
    color: "#ccc",
    fontSize: 18,
    marginVertical: 10,
  },
  button: {
    backgroundColor: "#1E90FF",
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 10,
    marginTop: 20,
  },
  buttonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
  },
});
