import React, { useEffect, useRef, useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import { CameraView, useCameraPermissions, useMicrophonePermissions } from "expo-camera";
import { useKeepAwake } from "expo-keep-awake";

export default function App() {
  useKeepAwake();

  const camRef = useRef<any>(null);
  const [camPerm, requestCamPerm] = useCameraPermissions();
  const [micPerm, requestMicPerm] = useMicrophonePermissions();

  const [recording, setRecording] = useState(false);
  const [savedPath, setSavedPath] = useState<string | null>(null);
  const [seconds, setSeconds] = useState(30);
  const [error, setError] = useState<string | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Solicita permissões
  useEffect(() => {
    (async () => {
      if (!camPerm?.granted) await requestCamPerm();
      if (!micPerm?.granted) await requestMicPerm();
    })();
  }, []);

  const startRecord = async () => {
    try {
      if (!camRef.current) throw new Error("Câmera não inicializada");
      setRecording(true);
      setError(null);
      setSavedPath(null);
      setSeconds(30);

      const video = await camRef.current.recordAsync({ maxDuration: 30 });

      // Caminho do vídeo
      setSavedPath(video.uri);
      setRecording(false);
    } catch (e: any) {
      setError(String(e?.message ?? e));
      setRecording(false);
    }
  };

  const stopRecord = async () => {
    try {
      await camRef.current?.stopRecording?.();
      setRecording(false);
    } catch (e: any) {
      setError(String(e?.message ?? e));
    }
  };

  // Contador de 30s
useEffect(() => {
  if (recording) {
    timerRef.current = setInterval(() => {
      setSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current!);
          stopRecord();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  } else if (timerRef.current) {
    clearInterval(timerRef.current);
  }

  
  return () => {
    if (timerRef.current) clearInterval(timerRef.current);
  };
}, [recording]);

  // Tela da aplicação
  return (
    <View style={styles.root}>
      <View style={styles.preview}>
        <CameraView ref={camRef} style={{ flex: 1 }} facing="back" mode="video" />
        {recording && (
          <View style={styles.recBadge}>
            <View style={styles.dot} />
            <Text style={styles.recText}>Gravando... ({seconds}s)</Text>
          </View>
        )}
      </View>

      <TouchableOpacity
        style={[styles.button, recording && styles.buttonDisabled]}
        onPress={recording ? stopRecord : startRecord}
      >
        <Text style={styles.buttonText}>
          {recording ? "Parar Gravação" : "Iniciar Gravação (30s)"}
        </Text>
      </TouchableOpacity>

      {savedPath && (
        <Text style={styles.info}>
          Vídeo salvo em:{"\n"}
          {savedPath}
        </Text>
      )}
      {error && <Text style={styles.error}>{error}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#000" },
  preview: { flex: 1 },
  recBadge: {
    position: "absolute",
    top: 16,
    left: 16,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.6)",
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
  },
  dot: { width: 10, height: 10, borderRadius: 5, backgroundColor: "#ff3b30", marginRight: 8 },
  recText: { color: "#fff", fontWeight: "600" },
  button: {
    margin: 16,
    backgroundColor: "#1e90ff",
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: "center",
  },
  buttonDisabled: { opacity: 0.6 },
  buttonText: { color: "#fff", fontSize: 16, fontWeight: "600" },
  info: {
    color: "#fff",
    textAlign: "center",
    marginHorizontal: 16,
    marginBottom: 12,
  },
  error: { color: "#ff6666", textAlign: "center", marginBottom: 12 },
});
